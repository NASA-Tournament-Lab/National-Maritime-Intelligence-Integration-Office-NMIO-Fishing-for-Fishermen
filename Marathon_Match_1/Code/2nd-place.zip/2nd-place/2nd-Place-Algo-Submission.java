import java.io.*;
import java.text.*;
import java.util.*;

public class FishingForFishermen {
	private Map<Integer, Entry> staticDataByMMSI = new HashMap<Integer, Entry>();

	public static void main(String[] args) {
		new FishingForFishermen().run("data/training_data.csv", "data/testing_data.csv", "data/static_reports_raw_corrected.csv", "wleite.csv");
	}

	void run(String trainingFile, String testingFile, String reportFile, String outFile) {
		readStaticReport(reportFile);
		Entry[] trainingEntries = parse(trainingFile, true);
		RandomForestPredictor rf = new RandomForestPredictor();
		rf.train(trainingEntries, 64);
		Entry[] testingEntries = parse(testingFile, false);
		double[] results = rf.predict(testingEntries);
		outputResults(outFile, results);
	}

	private void readStaticReport(String file) {
		try {
			BufferedReader in = new BufferedReader(new FileReader(file));
			String line = in.readLine();
			while ((line = in.readLine()) != null) {
				Entry e = new Entry(line, true);
				if (e.shipType > 0 && e.dimensionToBow > 0 && e.dimensionToPort > 0 && e.dimensionToStarboard > 0 && e.dimensionToStern > 0) {
					staticDataByMMSI.put(e.mmsi, e);
				}
			}
			in.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	private void outputResults(String outFile, double[] results) {
		try {
			DecimalFormat df = new DecimalFormat("0.00000000", DecimalFormatSymbols.getInstance(Locale.US));
			BufferedWriter out = new BufferedWriter(new FileWriter(new File(outFile)));
			for (int i = 0; i < results.length; i++) {
				out.write(df.format(results[i]));
				out.newLine();
			}
			out.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	private Entry[] parse(String file, boolean isTraining) {
		String[] l = read(file);
		List<Entry> entries = new ArrayList<Entry>();
		for (String s : l) {
			Entry e = new Entry(s, false);
			entries.add(e);
			if (isTraining && e.isFishing == -1) {
				e.isFishing = 1;
				Entry e2 = new Entry(s, false);
				e2.isFishing = 0;
				entries.add(e2);
			}
		}
		if (isTraining) {
			Collections.sort(entries);
			for (int i = 1; i < entries.size(); i++) {
				Entry a = entries.get(i - 1);
				Entry b = entries.get(i);
				if (a.latitude == b.latitude && a.longitude == b.longitude && a.msgType == b.msgType && a.mmsi == b.mmsi && a.isFishing == b.isFishing && a.time == b.time && a.speedOverGround == b.speedOverGround && a.timeStamp == b.timeStamp && a.repeatCount == b.repeatCount) {
					entries.remove(i--);
				}
			}
		}
		Entry[] ret = entries.toArray(new Entry[0]);
		updateEntries(ret);
		return ret;
	}

	private void updateEntries(Entry[] entries) {
		Map<Integer, List<Entry>> entriesByMMSI = new HashMap<Integer, List<Entry>>();
		for (Entry e : entries) {
			List<Entry> l = entriesByMMSI.get(e.mmsi);
			if (l == null) entriesByMMSI.put(e.mmsi, l = new ArrayList<Entry>());
			l.add(e);
		}
		for (List<Entry> l : entriesByMMSI.values()) {
			double lat = 0;
			double lng = 0;
			double repeat = 0;
			int cnt1 = 0;
			int cnt2 = 0;
			Collections.sort(l);
			Entry staticEntry = staticDataByMMSI.get(l.get(0).mmsi);

			for (Entry e : l) {
				if (staticEntry != null) {
					e.shipType = staticEntry.shipType;
					e.dimensionToBow = staticEntry.dimensionToBow;
					e.dimensionToPort = staticEntry.dimensionToPort;
					e.dimensionToStarboard = staticEntry.dimensionToStarboard;
					e.dimensionToStern = staticEntry.dimensionToStern;
				}
				if (e.latitude != -1000 && e.longitude != -1000) {
					cnt1++;
					lat += e.latitude;
					lng += e.longitude;
				}
				if (e.repeatCount != -1) {
					cnt2++;
					repeat += e.repeatCount;
				}
			}
			if (cnt1 > 0) {
				lat /= cnt1;
				lng /= cnt1;
				for (Entry e : l) {
					e.avgLatitude = lat;
					e.avgLongitude = lng;
				}
			}
			if (cnt2 > 0) {
				repeat /= cnt2;
				for (Entry e : l) {
					e.avgRepeatCount = repeat;
				}
			}
		}
	}

	private static String[] read(String file) {
		try {
			List<String> l = new ArrayList<String>();
			BufferedReader in = new BufferedReader(new FileReader(file));
			String line = in.readLine();
			while ((line = in.readLine()) != null) {
				l.add(line);
			}
			in.close();
			return l.toArray(new String[0]);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}
}

class Entry implements Comparable<Entry> {
	long time;
	int isFishing = -1;
	int channelCode = -1;
	int msgType = -1;
	int repeatCount = -1;
	int mmsi = -1;
	int navigationStatus = -1;
	int rateOfTurn = -1000;
	int speedOverGround = -1;
	int accuracy = -1;
	double longitude = -1000;
	double latitude = -1000;
	int courseOverGround = -1;
	int trueHeading = -1;
	int timeStamp = -1;
	int maneuverIndicator = -1;
	int raim = -1;
	int radioStatus = -1;
	int shipType = -1;
	int dimensionToBow = -1;
	int dimensionToStern = -1;
	int dimensionToPort = -1;
	int dimensionToStarboard = -1;
	int positionFixType = -1;
	double avgLongitude = -1000;
	double avgLatitude = -1000;
	double avgRepeatCount = -1000;
	boolean invalid = false;

	public Entry(String s, boolean isReport) {
		if (isReport) {
			int p1 = s.lastIndexOf(',');
			time = Long.parseLong(s.substring(p1 + 1));
		} else {
			int p1 = s.indexOf(',');
			time = Long.parseLong(s.substring(0, p1));
			if (s.endsWith(",Fishing")) isFishing = 1;
			if (s.endsWith(",Not Fishing")) isFishing = 0;
		}
		int p2 = s.indexOf('\"');
		int p3 = s.lastIndexOf('\"');
		parseAIS(s.substring(p2 + 1, p3), isReport);
	}

	private void parseAIS(String str, boolean isReport) {
		int start = 1;
		if (!str.startsWith("!AIVDM,1,1,")) {
			invalid = true;
			if (!str.startsWith("AIVDM,1,1,")) {
				System.err.println("INVALID DATA START: " + str);
				return;
			}
			start = 0;
		}
		String[] s = str.split(",");
		if (s[4].length() > 0) channelCode = s[4].charAt(0);
		if (!isReport) {
			if (!s[6].startsWith("0*")) {
				System.err.println("INVALID DATA END: " + str);
				invalid = true;
				return;
			}
			int actualCheckSum = 0;
			for (int i = start; i < str.length() - 3; i++) {
				actualCheckSum ^= str.charAt(i);
			}
			int msgCheckSum = Integer.parseInt(s[6].substring(2), 16);
			if (msgCheckSum != actualCheckSum) {
				System.err.println("CHECKSUM ERROR: " + actualCheckSum + " " + msgCheckSum + " " + str);
				invalid = true;
				return;
			}
		}
		parsePayload(s[5]);
	}

	private void parsePayload(String s) {
		StringBuilder sb = new StringBuilder();
		for (int i = 0; i < s.length(); i++) {
			int v = s.charAt(i) - '0';
			if (v > 40) v -= 8;
			String bits = Integer.toString(v, 2);
			for (int j = bits.length(); j < 6; j++) {
				sb.append('0');
			}
			sb.append(bits);
		}
		msgType = Integer.parseInt(sb.substring(0, 6), 2);
		repeatCount = Integer.parseInt(sb.substring(6, 8), 2);
		mmsi = Integer.parseInt(sb.substring(8, 38), 2);
		if (msgType == 1 || msgType == 2 || msgType == 3) {
			navigationStatus = Integer.parseInt(sb.substring(38, 42), 2);
			rateOfTurn = parseSigned(sb, 42, 50);
			speedOverGround = Integer.parseInt(sb.substring(50, 60), 2);
			accuracy = Integer.parseInt(sb.substring(60, 61), 2);
			longitude = parseSigned(sb, 61, 89) / 600000.0;
			latitude = parseSigned(sb, 89, 116) / 600000.0;
			courseOverGround = Integer.parseInt(sb.substring(116, 128), 2);
			trueHeading = Integer.parseInt(sb.substring(128, 137), 2);
			timeStamp = Integer.parseInt(sb.substring(137, 143), 2);
			maneuverIndicator = Integer.parseInt(sb.substring(143, 145), 2);
			raim = Integer.parseInt(sb.substring(148, 149), 2);
			radioStatus = Integer.parseInt(sb.substring(149, 168), 2);
		} else if (msgType == 18) {
			speedOverGround = Integer.parseInt(sb.substring(46, 56), 2);
			accuracy = Integer.parseInt(sb.substring(56, 57), 2);
			longitude = parseSigned(sb, 57, 85) / 600000.0;
			latitude = parseSigned(sb, 85, 112) / 600000.0;
			courseOverGround = Integer.parseInt(sb.substring(112, 124), 2);
			trueHeading = Integer.parseInt(sb.substring(124, 133), 2);
			timeStamp = Integer.parseInt(sb.substring(133, 139), 2);
			raim = Integer.parseInt(sb.substring(147, 148), 2);
			radioStatus = Integer.parseInt(sb.substring(148, 168), 2);
		} else if (msgType == 19) {
			speedOverGround = Integer.parseInt(sb.substring(46, 56), 2);
			accuracy = Integer.parseInt(sb.substring(56, 57), 2);
			longitude = parseSigned(sb, 57, 85) / 600000.0;
			latitude = parseSigned(sb, 85, 112) / 600000.0;
			courseOverGround = Integer.parseInt(sb.substring(112, 124), 2);
			trueHeading = Integer.parseInt(sb.substring(124, 133), 2);
			timeStamp = Integer.parseInt(sb.substring(133, 139), 2);
			shipType = Integer.parseInt(sb.substring(263, 271), 2);
			dimensionToBow = Integer.parseInt(sb.substring(271, 280), 2);
			dimensionToStern = Integer.parseInt(sb.substring(280, 289), 2);
			dimensionToPort = Integer.parseInt(sb.substring(289, 295), 2);
			dimensionToStarboard = Integer.parseInt(sb.substring(295, 301), 2);
			positionFixType = Integer.parseInt(sb.substring(301, 305), 2);
			raim = Integer.parseInt(sb.substring(305, 306), 2);
		} else if (msgType == 27) {
			accuracy = Integer.parseInt(sb.substring(38, 39), 2);
			raim = Integer.parseInt(sb.substring(39, 40), 2);
			navigationStatus = Integer.parseInt(sb.substring(40, 44), 2);
			longitude = parseSigned(sb, 44, 62) / 600.0;
			latitude = parseSigned(sb, 62, 79) / 600.0;
			speedOverGround = Integer.parseInt(sb.substring(79, 85), 2) * 10;
			courseOverGround = Integer.parseInt(sb.substring(85, 94), 2) * 10;
		} else if (msgType == 5) {
			shipType = Integer.parseInt(sb.substring(232, 240), 2);
			dimensionToBow = Integer.parseInt(sb.substring(240, 249), 2);
			dimensionToStern = Integer.parseInt(sb.substring(249, 258), 2);
			dimensionToPort = Integer.parseInt(sb.substring(258, 264), 2);
			dimensionToStarboard = Integer.parseInt(sb.substring(264, 270), 2);
		} else if (msgType == 24) {
			shipType = Integer.parseInt(sb.substring(40, 48), 2);
			dimensionToBow = Integer.parseInt(sb.substring(132, 141), 2);
			dimensionToStern = Integer.parseInt(sb.substring(141, 150), 2);
			dimensionToPort = Integer.parseInt(sb.substring(150, 156), 2);
			dimensionToStarboard = Integer.parseInt(sb.substring(156, 162), 2);
		} else System.err.println(">>" + msgType);
	}

	public long getTravel() {
		return (((long) mmsi) << 32) | time;
	}

	private static int parseSigned(StringBuilder sb, int start, int end) {
		int v = Integer.parseInt(sb.substring(start, end), 2);
		int len = end - start;
		if (v > 1 << (len - 1)) v = v - (1 << len);
		return v;
	}

	public int compareTo(Entry o) {
		return Long.compare(time, o.time);
	}
}

class RandomForestPredictor {
	private RandomForest rf;
	private final Calendar c = new GregorianCalendar(Locale.US);
	private Map<Integer, Integer> shipTypeMap = new HashMap<Integer, Integer>();
	private Map<Integer, Integer> navigationStatusMap = new HashMap<Integer, Integer>();

	public void train(final Entry[] entries, final int maxTrees) {
		buildMaps(entries);
		final double[][] trainingFeatures = extractFeatures(entries);
		final boolean[] val = new boolean[entries.length];
		for (int i = 0; i < entries.length; i++) {
			if (entries[i].isFishing != 0) val[i] = true;
		}
		rf = new RandomForest();
		for (int i = 0; i < maxTrees; i++) {
			rf.add(new ClassificationTree(trainingFeatures, val, i));
		}
	}

	public double[] predict(final Entry[] entries) {
		double[] ret = new double[entries.length];
		Map<Integer, Double> sum = new HashMap<Integer, Double>();
		Map<Integer, Integer> cnt = new HashMap<Integer, Integer>();
		for (int i = 0; i < ret.length; i++) {
			double[] features = extractFeatures(entries[i]);
			ret[i] = rf.predict(features);
			int mmsi = entries[i].mmsi;
			Double v = sum.get(mmsi);
			if (v == null) v = 0.0;
			sum.put(mmsi, v + ret[i]);
			Integer w = cnt.get(mmsi);
			if (w == null) w = 0;
			cnt.put(mmsi, w + 1);
		}
		for (int i = 0; i < ret.length; i++) {
			int mmsi = entries[i].mmsi;
			Double v = sum.get(mmsi);
			Integer w = cnt.get(mmsi);
			ret[i] = ret[i] * 0.9 + v / w * 0.1;
		}
		return ret;
	}

	private void buildMaps(Entry[] entries) {
		for (int i = 0; i < 2; i++) {
			final Map<Integer, Integer> tot = new HashMap<Integer, Integer>();
			final Map<Integer, Integer> isf = new HashMap<Integer, Integer>();
			for (Entry e : entries) {
				int val = i == 0 ? e.shipType : e.navigationStatus;
				Integer v = tot.get(val);
				if (v == null) v = 0;
				tot.put(val, v + 1);
				v = isf.get(val);
				if (v == null) v = 0;
				if (e.isFishing == 1) v++;
				isf.put(val, v);
			}
			List<Integer> keys = new ArrayList<Integer>(tot.keySet());
			Collections.sort(keys, new Comparator<Integer>() {
				public int compare(Integer a, Integer b) {
					return Integer.compare(tot.get(a) * isf.get(b), tot.get(b) * isf.get(a));
				}
			});
			Map<Integer, Integer> map = i == 0 ? shipTypeMap : navigationStatusMap;
			for (int j = 0; j < keys.size(); j++) {
				map.put(keys.get(j), j);
			}
		}
	}

	private double[][] extractFeatures(final Entry[] entries) {
		double[] objectFeatures = extractFeatures(entries[0]);
		double[][] dataFeatures = new double[objectFeatures.length][entries.length];
		for (int i = 0; i < entries.length; i++) {
			objectFeatures = extractFeatures(entries[i]);
			for (int j = 0; j < objectFeatures.length; j++) {
				dataFeatures[j][i] = objectFeatures[j];
			}
		}
		return dataFeatures;
	}

	private double[] extractFeatures(Entry entry) {
		List<Double> l = new ArrayList<Double>();
		l.add(entry.latitude);
		l.add(entry.longitude);
		l.add((double) entry.maneuverIndicator);
		l.add((double) entry.speedOverGround);
		l.add((double) entry.channelCode);
		c.setTimeInMillis(entry.time * 1000L);
		l.add((double) c.get(Calendar.MONTH));
		l.add((double) c.get(Calendar.DAY_OF_WEEK));
		l.add(entry.avgLongitude);
		l.add((double) entry.msgType);
		l.add(entry.avgRepeatCount);
		l.add((double) entry.repeatCount);
		l.add((double) Math.round(entry.longitude));
		Integer shipType = shipTypeMap.get(entry.shipType);
		l.add(shipType == null ? -1.0 : shipType);
		l.add((double) entry.dimensionToBow);
		l.add((double) entry.dimensionToStarboard);
		Integer navigationStatus = navigationStatusMap.get(entry.navigationStatus);
		l.add(navigationStatus == null ? -1.0 : navigationStatus);
		l.add((double) entry.dimensionToStern);
		l.add((double) entry.dimensionToPort);

		double[] ret = new double[l.size()];
		for (int i = 0; i < ret.length; i++) {
			ret[i] = l.get(i);
		}
		return ret;
	}
}

class RandomForest {
	private List<ClassificationTree> trees = Collections.synchronizedList(new ArrayList<ClassificationTree>());

	public void add(ClassificationTree tree) {
		trees.add(tree);
	}

	public int size() {
		return trees.size();
	}

	public double predict(double[] features) {
		int cnt = 0;
		double ret = 0;
		for (ClassificationTree tree : trees) {
			ret += tree.classify(features);
			cnt++;
		}
		return ret / cnt;
	}
}

class ClassificationTree {
	private Node root;
	private Random rnd;

	public ClassificationTree(double[][] features, boolean[] classif, int seed) {
		rnd = new Random(19720909 + seed);
		int numFeatures = features.length;
		int featuresSteps = numFeatures;
		int totRows = features[0].length;
		int splitSteps = (int) (Math.sqrt(totRows) / 16);
		int[] selRows = new int[totRows];
		for (int i = 0; i < totRows; i++) {
			selRows[i] = rnd.nextInt(totRows);
		}
		int classifCount = 0;
		for (int row : selRows) {
			if (classif[row]) classifCount++;
		}
		List<Node> nodes = new ArrayList<>();
		root = new Node(classifCount, impurity(classifCount, totRows), 0, totRows - 1);
		nodes.add(root);
		double[] prevSplitVal = new double[splitSteps];
		for (int i = 0; i < nodes.size(); i++) {
			Node node = nodes.get(i);
			if (node.isPure() || node.getNumRows() <= 2) continue;
			double maxSplitGain = 0;
			double bestSplitVal = 0;
			int bestSplitFeature = -1;
			for (int j = 0; j < featuresSteps; j++) {
				int splitFeature = rnd.nextInt(numFeatures);
				double[] featuresSplitFeature = features[splitFeature];
				NEXT: for (int k = 0; k < splitSteps; k++) {
					double splitVal = prevSplitVal[k] = featuresSplitFeature[randomNodeRow(selRows, node)];
					for (int l = 0; l < k; l++) {
						if (splitVal == prevSplitVal[l]) continue NEXT;
					}
					int leftTot = 0;
					int rightTot = 0;
					int leftClassif = 0;
					int rightClassif = 0;
					for (int r = node.startRow; r <= node.endRow; r++) {
						int row = selRows[r];
						if (featuresSplitFeature[row] < splitVal) {
							if (classif[row]) leftClassif++;
							leftTot++;
						} else {
							if (classif[row]) rightClassif++;
							rightTot++;
						}
					}
					if (leftTot == 0 || rightTot == 0) continue;
					double splitGain = node.impurity - impurity(leftClassif, leftTot, rightClassif, rightTot);
					if (splitGain > maxSplitGain) {
						maxSplitGain = splitGain;
						bestSplitFeature = splitFeature;
						bestSplitVal = splitVal;
					}
				}
			}
			if (bestSplitFeature >= 0) {
				int leftTot = 0;
				int rightTot = 0;
				int leftClassif = 0;
				int rightClassif = 0;
				int endLeft = node.endRow;
				for (int r = node.startRow; r <= endLeft; r++) {
					int row = selRows[r];
					if (features[bestSplitFeature][row] < bestSplitVal) {
						if (classif[row]) leftClassif++;
						leftTot++;
					} else {
						if (classif[row]) rightClassif++;
						rightTot++;
						selRows[r--] = selRows[endLeft];
						selRows[endLeft--] = row;
					}
				}
				node.left = new Node(leftClassif, impurity(leftClassif, leftTot), node.startRow, endLeft);
				node.right = new Node(rightClassif, impurity(rightClassif, rightTot), endLeft + 1, node.endRow);
				nodes.add(node.left);
				nodes.add(node.right);
				node.splitVal = bestSplitVal;
				node.splitFeature = bestSplitFeature;
			}
		}
	}

	private final double impurity(int cnt, int tot) {
		double val = 0;
		if (cnt > 0) {
			double p = cnt / (double) tot;
			val -= p * Math.log(p);
		}
		if (tot - cnt > 0) {
			double p = (tot - cnt) / (double) tot;
			val -= p * Math.log(p);
		}
		return val;
	}

	private final double impurity(int cnt1, int tot1, int cnt2, int tot2) {
		return (impurity(cnt1, tot1) * tot1 + impurity(cnt2, tot2) * tot2) / (tot1 + tot2);
	}

	public double classify(double[] features) {
		Node node = root;
		while (!node.isLeaf()) {
			if (features[node.splitFeature] < node.splitVal) node = node.left;
			else node = node.right;
		}
		return node.getValue();
	}

	private final int randomNodeRow(int[] rows, Node node) {
		return rows[rnd.nextInt(node.getNumRows()) + node.startRow];
	}
}

class Node {
	Node left, right;
	int classif, splitFeature, startRow, endRow;
	double splitVal, impurity;

	Node(int classif, double impurtity, int startRow, int endRow) {
		this.classif = classif;
		this.startRow = startRow;
		this.endRow = endRow;
		this.impurity = impurtity;
	}

	double getValue() {
		return classif / (double) getNumRows();
	}

	boolean isLeaf() {
		return left == null && right == null;
	}

	boolean isPure() {
		return classif == 0 || classif == getNumRows();
	}

	int getNumRows() {
		return endRow - startRow + 1;
	}
}

class Random {
	private static final long mask0 = 0x80000000L;
	private static final long mask1 = 0x7fffffffL;
	private static final long[] mult = new long[] {0,0x9908b0dfL};
	private final long[] mt = new long[624];
	private int idx = 0;

	Random(long seed) {
		init(seed);
	}

	private void init(long seed) {
		mt[0] = seed & 0xffffffffl;
		for (int i = 1; i < 624; i++) {
			mt[i] = 1812433253l * (mt[i - 1] ^ (mt[i - 1] >>> 30)) + i;
			mt[i] &= 0xffffffffl;
		}
	}

	private void generate() {
		for (int i = 0; i < 227; i++) {
			long y = (mt[i] & mask0) | (mt[i + 1] & mask1);
			mt[i] = mt[i + 397] ^ (y >> 1) ^ mult[(int) (y & 1)];
		}
		for (int i = 227; i < 623; i++) {
			long y = (mt[i] & mask0) | (mt[i + 1] & mask1);
			mt[i] = mt[i - 227] ^ (y >> 1) ^ mult[(int) (y & 1)];
		}
		long y = (mt[623] & mask0) | (mt[0] & mask1);
		mt[623] = mt[396] ^ (y >> 1) ^ mult[(int) (y & 1)];
	}

	private long rand() {
		if (idx == 0) generate();
		long y = mt[idx];
		idx = (idx + 1) % 624;
		y ^= (y >> 11);
		y ^= (y << 7) & 0x9d2c5680l;
		y ^= (y << 15) & 0xefc60000l;
		return y ^ (y >> 18);
	}

	int nextInt(int n) {
		return (int) (rand() % n);
	}
}