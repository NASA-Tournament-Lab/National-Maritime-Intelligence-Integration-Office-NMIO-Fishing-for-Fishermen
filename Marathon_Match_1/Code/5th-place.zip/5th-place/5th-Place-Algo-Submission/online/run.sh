if [ -z $2 ];
then
	echo "Usage: run <inputfile> <outputfile>"
	exit 1
fi

pushd `dirname $0`/FishingForFishermen
make run TESTING_DATA_RAW=$1 FINAL_RESULT=$2
popd
