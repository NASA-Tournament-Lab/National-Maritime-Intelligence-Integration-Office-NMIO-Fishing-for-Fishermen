pushd `dirname $0`/FishingForFishermen
make compile
popd
