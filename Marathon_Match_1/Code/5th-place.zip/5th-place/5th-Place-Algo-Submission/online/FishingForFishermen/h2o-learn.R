#!/usr/bin/Rscript

library(h2o)
H2OConnection = h2o.init(nthreads = 4, max_mem_size = "4G")

source('functions.R')
load("work/training.RData")
load("work/training_spots.RData")

models = multiLearn(train, "model/", "rf")
save(models, file = "model/models.RData")
print(models)

datasets = c("train", "cross")
layout(matrix(1:length(datasets), 1, length(datasets)))

for (i in 1:length(datasets))
{
    data = get(datasets[i])

    n = ncol(data)
    truth = data[, n]
    data = data[, -n]

    results = multiPredict(data, models, truth)
    write.table(results, paste0("tmp/res_", datasets[i]), sep = ",", row.names = F, col.names = F)
    
	if (i == 2)
	{
		thresholds = proposeThresholds(results, truth, data)
		modified = modifyThresholds(results, data, thresholds)
		save(thresholds, file = "model/thresholds.RData")
		compare(modified, truth)
	}
}
