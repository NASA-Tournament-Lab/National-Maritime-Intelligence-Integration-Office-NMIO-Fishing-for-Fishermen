#!/usr/bin/Rscript

if (!require(stats))
	install.packages(stats)

if (!require(data.table))
	install.packages(data.table)

if (!require(h2o))
	install.packages(h2o)

quit(save = "no", status = ifelse(require(stats) & require(data.table) & require(h2o), 0, 1))
