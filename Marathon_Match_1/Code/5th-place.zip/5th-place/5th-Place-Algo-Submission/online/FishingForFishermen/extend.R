#!/usr/bin/Rscript

library(data.table)

source('functions.R')

extend = function(input.file, output.file, static.file)
{
	input = read.table(input.file, header = T, sep = ",")
	m = nrow(input)

	static = read.table(static.file, header = T, sep = ",")
	names(static) = c("TIMESTAMP", "MESSAGE_ID", "MMSI", "TYPE", "TO_BOW", "TO_STERN", "TO_PORT", "TO_STARBOARD", "DRAUGHT")

	n = ncol(static)

	extension = data.frame(
		"TIMESTAMP" = rep(0, m),
		"MESSAGE_ID" = rep(0, m),
		"MMSI" = rep(0, m),
		"TYPE" = rep(0, m),
		"TO_BOW" = rep(0, m),
		"TO_STERN" = rep(0, m),
		"TO_PORT" = rep(0, m),
		"TO_STARBOARD" = rep(0, m),
		"DRAUGHT" = rep(0, m))

	for (i in 1:m)
	{
		if (i %% 1000 == 0)
			print(paste("Processing line ", i, " of ", m))

		s = static[static$MMSI == input$MMSI[i], ]

		if (nrow(s) > 0)
		{
			for (j in 1:n)
				set(extension, i, j, s[1, j])
		}
		else
		{
			set(extension, i, 3, input$MMSI[i])
		}
	}

	write.table(extension, output.file, sep = ",", row.names = F, col.names = T)
}

args = commandArgs(trailingOnly = T)

if (length(args) > 2)
	extend(args[1], args[2], args[3])
