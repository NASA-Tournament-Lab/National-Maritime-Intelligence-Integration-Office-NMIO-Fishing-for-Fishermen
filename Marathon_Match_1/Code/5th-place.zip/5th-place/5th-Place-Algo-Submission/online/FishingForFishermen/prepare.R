#!/usr/bin/Rscript

source('functions.R')

# Parameters
p = 1 # fraction of samples to use

# Input
data = read.table("work/training_data.csv", header = T, sep = ",")
load("work/training_spots.RData")
data$SPOT = data.spots

print(paste("NA count", sum(is.na(data))))
data = addextension(data, "work/training_extension.csv")

# Clear unknown
data = data[data$FISHING_STATUS != "Unknown", ]
#data = data[data$SPOT != 5, ]
#data = data[data$SPOT != 6, ]

# Reduce dataset
m = dim(data)[1] # total number of samples

library(stats)
set.seed(as.integer(1 / p))
s = sample(m, m * p)

data = data[s, ]
m = dim(data)[1] # total number of samples

data = addFeatures(data)
data = removeFeatures(data)

# Move status to the end of the frame
status = factor(data$FISHING_STATUS, levels = c("Not Fishing", "Fishing"))
data$FISHING_STATUS = NULL
data$FISHING_STATUS = as.numeric(status) - 1

# Show the resulting names
print(names(data))

# Split the data
s = sample(m)
s = split(s, c(1, 1, 1, 1, 2))

# Write the result
all = data
train = data[unlist(s[1]), ]
cross = data[unlist(s[2]), ]

write.table(all, file = "tmp/all.csv", sep = ",", row.names = F, col.names = T)
write.table(train, file = "tmp/train.csv", sep = ",", row.names = F, col.names = T)
write.table(cross, file = "tmp/cross.csv", sep = ",", row.names = F, col.names = T)
save(all, train, cross, file = "work/training.RData")
