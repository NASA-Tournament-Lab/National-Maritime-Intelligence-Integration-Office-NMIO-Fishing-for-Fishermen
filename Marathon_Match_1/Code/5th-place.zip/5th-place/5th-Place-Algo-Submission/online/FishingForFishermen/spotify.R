#!/usr/bin/Rscript

source('functions.R')

args = commandArgs(trailingOnly = T)
radius = 10

if (length(args) > 1)
{
	data = read.table(args[1], sep = ",", header = T)
	data$FISHING_STATUS = NULL

	spots = NULL

	if (length(args) == 2)
	{
		spots = find_spots(data, radius)
		print(spots)
	}
	else
	{
		load(args[3])
	}

	print("Assigning spots")
	data.spots = spotify(data, spots, radius)

	save(spots, data.spots, file = args[2])
}
