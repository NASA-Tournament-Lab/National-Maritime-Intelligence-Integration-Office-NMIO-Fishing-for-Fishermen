sigmoid = function(x, speed = 1, intercept = 0)
{
	return(1 / (1 + exp(-speed * (x - intercept))))
}

mse = function (prediction, truth)
{
	return(sum((truth - prediction) ^ 2) / length(truth))
}

rates = function (prediction, truth, threshold = 0.5)
{
	prediction = as.numeric(prediction >= threshold)
	truth = as.numeric(truth >= threshold)

	PP = sum(prediction)
	RP = sum(as.numeric(truth == 1))
	TP = sum(prediction[truth == 1])
	FN = RP - TP

	RN = sum(as.numeric(truth == 0))
	FP = sum(prediction[truth == 0])
	TN = RN - FP

	Precision = TP / PP
	Recall = TP / RP
	Fallout = FP / RN
	F1Metric = 2 * Precision * Recall / (Precision + Recall)
	MCC = (TP * TN - FP * FN) / sqrt((TP + FP) * (TP + FN) * (TN + FP) * (TN + FN))

	return(data.frame("TP" = TP, "FN" = FN, "FP" = FP, "TN" = TN, "Precision" = Precision, "TPR (Recall)" = Recall, "FPR (Fall-out)" = Fallout, "F1Metric" = F1Metric, "MCC" = MCC))
}

auc = function (prediction, truth, threshold = 0.5)
{
	m = length(prediction)
	df = data.frame("Prediction" = prediction, "Index" = m:1, "Truth" = truth)
	df = df[order(df$Prediction, df$Index, decreasing = T), ]

	N_TPR = sum(truth)
	N_FPR = m - N_TPR

	TPR = rep(0, m)
	FPR = rep(0, m)
	t = 0
	f = 0

	for (j in 1:m)
	{
		t = t + df$Truth[j] / N_TPR
		TPR[j] = t

		f = f + (1 - df$Truth[j]) / N_FPR
		FPR[j] = f
	}

	AuC = TPR[1] * FPR[1] + sum(TPR[2:m] * (FPR[2:m] - FPR[1:(m - 1)]))

	if (F)
	{
		plot(FPR, TPR, col = 'red', pch = 18, cex = 0.5, xlim = c(0, 1), ylim = c(0, 1), bty = 'n');
		axis(1, at = seq(0, 1, 0.1))
		axis(2, at = seq(0, 1, 0.1))
		grid()
		abline(0, 1)
	}

	return(AuC)
}

compare = function (prediction, truth, threshold = 0.5, m = length(prediction))
{
	original = prediction
    discrete = as.numeric(original >= threshold)

    df.rates = cbind("MSE" = c(mse(discrete, truth)), rates(discrete, truth), "AuC" = auc(original, truth, threshold))

    print(df.rates)
}

distance = function(from.x, from.y, to.x, to.y)
{
	return(sqrt((from.x - to.x) ^ 2 + (from.y - to.y) ^ 2))
}

find_spots = function(frame, radius)
{
	m = nrow(frame)
	spots = NULL

	for (i in 1:m)
	{
		if (i %% 1000 == 0)
			print(paste("At", i, "out of", m))

		if (is.null(spots))
		{
			spots = data.frame("X" = frame$LONG[i], "Y" = frame$LAT[i])
		}
		else
		{
			ds = unlist(lapply(1:nrow(spots), function(x) { return(distance(frame$LONG[i], frame$LAT[i], spots$X[x], spots$Y[x])) }))
			d = min(ds)

			if (d > radius)
				spots = rbind(spots, list(frame$LONG[i], frame$LAT[i]))
		}
	}

	return(spots)
}

spotify = function(frame, spots, radius)
{
	m = nrow(frame)
	n = nrow(spots)
	other = n + 1
	spot = rep(other, m)

	for (i in 1:m)
	{
		if (i %% 1000 == 0)
			print(paste("At", i, "out of", m))

		ds = unlist(lapply(1:n, function(x) { return(distance(frame$LONG[i], frame$LAT[i], spots$X[x], spots$Y[x])) }))
		spot[i] = ifelse(min(ds) <= radius, which.min(ds), other)
	}

	return(spot)
}

addFeatures = function(frame)
{
	m = nrow(frame)

	t = as.POSIXlt(frame$TIMESTAMP, origin="1970/01/01", "GMT")
	names(t) = c("sec", "min", "hour", "mday", "mon", "year", "wday", "yday", "isdst")

	frame$minute = t$hour * 60 + t$min
	frame$hour = t$hour
	frame$weekday = t$wday
	frame$monthday = t$mday
	frame$yearday = t$yday
	frame$month = t$mon

	x = rep(0, m)
	y = rep(0, m)

	for (i in 1:m)
	{
		if (i %% 1000 == 0)
			print(paste("At", i, "out of", m))

		x[i] = frame$LONG[i] - spots$X[frame$SPOT[i]]
		y[i] = frame$LAT[i] - spots$Y[frame$SPOT[i]]
	}
	
	frame$x = x
	frame$y = y

	frame$x2 = frame$x ^ 2
	frame$y2 = frame$y ^ 2
	frame$distance = sqrt(frame$x2 + frame$y2)

	return(frame)
}

removeFeatures = function(frame)
{
	#frame$TIMESTAMP = NULL
	frame$TIME = NULL
	#frame$MESSAGE_ID = NULL
	#frame$MMSI = NULL
	#frame$LAT = NULL
	#frame$LONG = NULL
	#frame$SOG = NULL
	#frame$COG = NULL
	#frame$TRUE_HEADING = NULL
	#frame$POS_ACCURACY = NULL
	#frame$NAV_STATUS = NULL
	frame$RAW_MESSAGE = NULL
	#frame$SPOT = NULL

	return(frame)
}

addextension = function(frame, path)
{
	ext = read.table(path, header = T, sep = ",")
	ext$TIMESTAMP = NULL
	ext$MESSAGE_ID = NULL
	ext$MMSI = NULL

	return(cbind(frame, ext))
}

createModel = function(data, path, method)
{
	dir.create(path, recursive = T)
	
	m = nrow(data)
	n = ncol(data)
	truth = data[, n]
	data = data[, -n]

	maxs <- apply(data, 2, max)
	mins <- apply(data, 2, min)
	means <- apply(data, 2, median)
	save(maxs, mins, means, file = paste0(path, "mmm.RData"))
	scaled <- as.data.frame(scale(data, center = means, scale = maxs - mins))
	model = NULL

	if (method == "dlm")
	{
		h2odata = as.h2o(cbind(scaled, truth))
		model <- h2o.deeplearning(x = 1:(n - 1),
								  y = n,
								  training_frame = h2odata,
								  activation = "Rectifier",
								  input_dropout_ratio = 0.1,
#								  hidden_dropout_ratios = c(0.1, 0.1, 0.1),
								  hidden = c(5 * n, 5 * n, 5 * n, 5 * n),
#								  l2 = 0.01,
								  epochs = 50
		)
	}
	else if (method == "dl")
	{
		h2odata = as.h2o(cbind(scaled, as.factor(ifelse(truth == 1, 1, 0))))
		model <- h2o.deeplearning(x = 1:(n - 1),
								  y = n,
								  training_frame = h2odata,
								  activation = "Tanh",
								  loss = "CrossEntropy",
								  stopping_metric = "AUC",
								  hidden = c(5 * n, 5 * n, 5 * n, 5 * n),
#								  l1 = 0.01,
#								  l2 = 0.01,
								  epochs = 50
		)
	}
	else if (method == "rf")
	{
		h2odata = as.h2o(cbind(scaled, as.factor(ifelse(truth == 1, 1, 0))))
		model <- h2o.randomForest(x = 1:(n - 1),
								  y = n,
								  training_frame = h2odata,
								  ntrees = 4 * n,
								  max_depth = 2 * n,
								  binomial_double_trees = T,
								  nfolds = 5
		)
	}

	modelpath = ""

	if (!is.null(model))
		modelpath = h2o.saveModel(object = model, path = path, force = T)

	return(modelpath)
}

useModel = function(data, modelpath)
{
	load(paste0(dirname(modelpath), "/mmm.RData"))
	data = data[names(means)]
	scaled <- as.data.frame(scale(data, center = means, scale = maxs - mins))

	h2odata = as.h2o(scaled)
	model = h2o.loadModel(modelpath)
	h2ores <- h2o.predict(object = model, newdata = h2odata)
	return(as.vector(as.numeric(ifelse(ncol(h2ores) == 3, h2ores$p1, h2ores$predict))))
}

filterMainFeatures = function(data)
{
	#data$TIMESTAMP = NULL
	data$MESSAGE_ID = NULL
	#data$MMSI = NULL
	data$LAT = NULL
	data$LONG = NULL
	data$POS_ACCURACY = NULL
	#data$NAV_STATUS = NULL
	#data$SOG = NULL
	#data$COG = NULL
	#data$TRUE_HEADING = NULL

	data$SPOT = NULL

	#data$TYPE = NULL
	#data$TO_BOW = NULL
	#data$TO_STERN = NULL
	#data$TO_PORT = NULL
	#data$TO_STARBOARD = NULL
	#data$DRAUGHT = NULL

	#data$minute = NULL
	data$hour = NULL
	data$weekday = NULL
	#data$monthday = NULL
	#data$yearday = NULL
	#data$month = NULL

	data$distance = NULL
	data$y = NULL
	data$x = NULL
	data$x2 = NULL
	data$y2 = NULL

	return(data)
}

filterFeatures = function(data)
{
	#data$TIMESTAMP = NULL
	data$MESSAGE_ID = NULL
	#data$MMSI = NULL
	data$LAT = NULL
	data$LONG = NULL
	data$POS_ACCURACY = NULL
	#data$NAV_STATUS = NULL
	#data$SOG = NULL
	#data$COG = NULL
	#data$TRUE_HEADING = NULL

	data$SPOT = NULL

	#data$TYPE = NULL
	#data$TO_BOW = NULL
	#data$TO_STERN = NULL
	#data$TO_PORT = NULL
	#data$TO_STARBOARD = NULL
	#data$DRAUGHT = NULL

	#data$minute = NULL
	data$hour = NULL
	data$weekday = NULL
	#data$monthday = NULL
	#data$yearday = NULL
	#data$month = NULL

	#data$distance = NULL
	#data$y = NULL
	#data$x = NULL
	#data$x2 = NULL
	#data$y2 = NULL

	return(data)
}

multiLearn = function(alldata, path, method)
{
	n = nrow(spots)
	print("Generating main model")
	modelForSpot = rep(createModel(filterMainFeatures(alldata), paste0(path, "h2o/0/"), method), n + 1)

	for (spot in 1:n)
	{
		print(paste("Generating model for spot", spot))

		data = alldata[alldata$SPOT == spot, ]
		data = filterFeatures(data)

		print(paste("Found", nrow(data), "training samples with", ncol(data), "features"))

		if (nrow(data) > ncol(data))
			if (nrow(data[data[, ncol(data)] == data[1, ncol(data)], ]) < nrow(data))
				modelForSpot[spot] = createModel(data, paste0(path, "h2o/", spot, "/"), method)
	}

	return(modelForSpot)
}

multiPredict = function(alldata, models, truth = NULL)
{
#	load("spots.RData")

	m = nrow(alldata)
	alldata = cbind(1:m, alldata)

	n = nrow(spots)
	results = data.frame()

	for (spot in 1:(n + 1))
	{
		modelpath = models[spot]
		data = alldata[alldata$SPOT == spot, ]

		print(paste("Generating prediction for spot", spot, "with", nrow(data), "samples, based on", modelpath))

		if (nrow(data) > 0)
		{
			indices = data[, 1]
			p = useModel(data[, -1], modelpath)

			results = rbind(results, data.frame(indices, p))
		}
	}

	results = results[order(results[, 1]), ]
	results = results[, 2]

	if (!is.null(truth))
		compare(results, truth)

	return(results)
}

FN = function(prediction, truth, threshold = 0.5)
{
	prediction = as.integer(prediction >= threshold)
	truth = as.integer(truth >= 0.5)

	return(prediction == 0 & truth == 1)
}

FP = function(prediction, truth, threshold = 0.5)
{
	prediction = as.integer(prediction >= threshold)
	truth = as.integer(truth >= 0.5)

	return(prediction == 1 & truth == 0)
}

TN = function(prediction, truth, threshold = 0.5)
{
	prediction = as.integer(prediction >= threshold)
	truth = as.integer(truth >= 0.5)

	return(prediction == 0 & truth == 0)
}

TP = function(prediction, truth, threshold = 0.5)
{
	prediction = as.integer(prediction >= threshold)
	truth = as.integer(truth >= 0.5)

	return(prediction == 1 & truth == 1)
}

F1 = function(tp, tn, fp, fn)
{
	P = tp / (tp + fp)
	R = tp / (tp + fn)
	return(2 * P * R / (P + R))
}

multiPredictWithValidation = function(data, mainModels, validationModels, truth = NULL)
{
	res.main = multiPredict(data, mainModels)
	res.validation = multiPredict(data, validationModels)

	res.mixed = res.main
	fp = FP(res.main, res.validation)
	fn = FN(res.main, res.validation)
	selection = fp | fn
	print(paste("Found", sum(fp), "FPs and ", sum(fn), "FNs"))
	res.mixed[selection] = sigmoid(res.mixed[selection], 0.5, 0.5)

	if (!is.null(truth))
	{
		compare(res.main, truth)
		compare(res.validation, truth)
		compare(res.mixed, truth)
	}

	return(res.mixed)
}

modifyThresholds = function(results, frame, thresholds)
{
	results = as.vector(results)

	n = length(thresholds)
	for (i in 1:n)
		results[frame$SPOT == i] = results[frame$SPOT == i] * 0.5 / thresholds[i]

	results = results / max(results)
	return(results)
}

proposeThresholds = function(prediction, truth, frame)
{
	print("Preparing thresholds")

	prediction = as.vector(prediction)
	initial.threshold = 0.5
	thresholds = rep(initial.threshold, nrow(spots) + 1)
	thresholds[length(thresholds)] = 0.8

	for (i in 1:length(thresholds))
	{
		if (sum(frame$SPOT == i) > 0)
		{
			f_auc = function(threshold)
			{
				th = thresholds
				th[i] = threshold
				modified = modifyThresholds(prediction, frame, th)
				return(auc(modified, truth))
			}

			x = seq(thresholds[i] - 0.1, thresholds[i] + 0.1, 0.001)
			y = unlist(lapply(x, f_auc))
			w = which.max(y)
			plot(x, y, main = paste("Spot", i), pch = 18, cex = 0.7)
			print(paste("Best threshold for spot", i, "is at position", w, " with x", x[w], "which brings AUC of", y[w]))

			thresholds[i] = x[w]
		}
	}

	return(thresholds)
}
