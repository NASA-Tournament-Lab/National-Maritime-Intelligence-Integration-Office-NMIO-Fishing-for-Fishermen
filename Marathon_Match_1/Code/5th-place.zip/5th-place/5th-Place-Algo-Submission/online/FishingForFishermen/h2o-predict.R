#!/usr/bin/Rscript

library(h2o)
H2OConnection = h2o.init(nthreads = 4, max_mem_size = "4G")

args = commandArgs(trailingOnly = T)

source('functions.R')
load("work/testing.RData")
load("work/testing_spots.RData")

load("model/used-models.RData")
results = multiPredict(test, models)

load("model/used-thresholds.RData")

if (!is.null(thresholds))
{
	print(paste("Using thresholds:", thresholds))
	results = modifyThresholds(results, test, thresholds)
}

print(paste("Writing results to:", args[1]))
write.table(results, file = args[1], sep = ",", row.names = F, col.names = F)
