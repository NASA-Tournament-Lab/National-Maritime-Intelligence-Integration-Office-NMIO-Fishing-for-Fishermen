#!/usr/bin/Rscript

compact = function(input, output)
{
	print("Reading file...")

	static = read.table(input, sep = ",", header = F)
	names(static) = c("TIMESTAMP", "MESSAGE_ID", "MMSI", "TYPE", "TO_BOW", "TO_STERN", "TO_PORT", "TO_STARBOARD", "DRAUGHT")
	reduced = data.frame()

	print("Sorting input...")
	static = static[order(static$MMSI), ]
	
	m = nrow(static)
	i = 1
	while (i <= m)
	{
		print(paste("At", i, "out of", m))

		mmsi = static$MMSI[i]
		filtered = static[static$MMSI == mmsi, ]
		values = apply(filtered, 2, max)
		reduced = rbind(reduced, values)
		i = i + nrow(filtered)
	}

	print("Writing results to file...")

	names(reduced) = names(static)
	write.table(reduced, output, sep = ",", row.names = F, col.names = T)
}

args = commandArgs(trailingOnly = T)

if (length(args) > 1)
	compact(args[1], args[2])
