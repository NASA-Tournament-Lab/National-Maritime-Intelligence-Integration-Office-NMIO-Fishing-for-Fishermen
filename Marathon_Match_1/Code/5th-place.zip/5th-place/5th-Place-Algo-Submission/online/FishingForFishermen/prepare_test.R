#!/usr/bin/Rscript

source('functions.R')

# Input
data = read.table("work/testing_data.csv", header = T, sep = ",")
load("work/testing_spots.RData")
data$SPOT = data.spots

data = addextension(data, "work/testing_extension.csv")
data = addFeatures(data)
data = removeFeatures(data)

# Show the resulting names
print(names(data))

test = data
write.table(data, file = "tmp/testing.csv", sep = ",", row.names = F, col.names = T)
save(test, file = "work/testing.RData")
