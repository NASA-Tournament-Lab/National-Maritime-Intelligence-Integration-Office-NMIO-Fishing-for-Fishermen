#include <vector>
#include <string>
#include <fstream>
#include <iostream>
#include <iomanip>
#include "bitqueue.h"

using namespace std;
using utility::bitqueue;

size_t strsplit(const string &s, vector<string> &v, const char *delims)
{
	v.clear();

	for (size_t start = 0, end = 0; end != string::npos; start = end + 1)
	{
		end = s.find_first_of(delims, start);
		v.emplace_back(s, start, end - start);
	}

	return v.size();
}

class Message
{
public:
	static bool unpack(const string &s, bitqueue &bq, unsigned &type)
	{
		// !AIVDM,1,1,,B,35NJH:POhiD:=RpO<EFFbUpB0000,0*19
		vector<string> v;

		bool ok =
			(strsplit(s, v, ",") >= 6) &&
			v[0] == "AIVDM" &&
			v[1] == "1" &&
			v[2] == "1";

		type = (ok && v[5].size() > 0) ? v[5][0] - '0' : 0;

		if (ok)
		{
			v[5].resize(((v[5].size() + 3) >> 2) * 4, '0');
			decrypt(v[5], bq);
		}

		return ok;
	}

	static void decrypt(const string &s, bitqueue &bq)
	{
		bq.clear();

		for (int i = 0; i < s.size(); ++i)
			bq.push(6, s[i] - (s[i] > 88 ? 56 : 48));

		bq.push(32, 0);
		bq.push(32, 0);
	}

	virtual void decode(bitqueue &bq)
	{
		print(0, 1, 2, 3, 4, 5, 6, 7, 8);
	}

protected:
	// TIMESTAMP,TIME,MESSAGE_ID,MMSI,LAT,LONG,POS_ACCURACY,NAV_STATUS,SOG,COG,TRUE_HEADING,RAW_MESSAGE,FISHING_STATUS
	void print(int id, int mmsi, double Lat, double Long, int accuracy, int status, double sog, double cog, int heading)
	{
		cout << dec << id << "," << mmsi << "," << setprecision(9) << Lat << "," << Long << "," << accuracy << "," << status << "," << setprecision(4) << sog << "," << cog << "," << heading << endl;
	}

	// MESSAGE_ID,MMSI,TYPE,TO_BOW,TO_STERN,TO_PORT,TO_STARBOARD,DRAUGHT
	void print_static(int id, int mmsi, int type, int to_bow, int to_stern, int to_port, int to_starboard, int draught)
	{
		cout << id << "," << mmsi << "," << type << "," << to_bow << "," << to_stern << "," << to_port << "," << to_starboard << "," << draught << endl;
	}
};

class Message_1_2_3 : public Message
{
private:
	virtual void decode(bitqueue &bq)
	{
		const unsigned id = bq.pop(6);
		bq.pop(2); // repeat
		const unsigned mmsi = bq.pop(30);
		const unsigned status = bq.pop(4);
		bq.pop(8); // turn
		const unsigned speed = bq.pop(10);
		const unsigned accuracy = bq.pop(1);
		const int lon = bq.pop_signed(28);
		const int lat = bq.pop_signed(27);
		const unsigned course = bq.pop(12);
		const unsigned heading = bq.pop(9);
		// second 6
		// maneuver 2
		// reserved 3
		// raim 1
		// radio 19

		print(id, mmsi, lat / 600000.0, lon / 600000.0, accuracy, status, speed / 10.0, course / 10.0, heading);
	}
};

class Message_5 : public Message
{
private:
	virtual void decode(bitqueue &bq)
	{
		const unsigned id = bq.pop(6);
		bq.pop(2); // repeat
		const unsigned mmsi = bq.pop(30);
		bq.pop(2); // ais_version
		bq.pop(30); // imo
		bq.pop(20); bq.pop(22); // callsign
		bq.pop(30); bq.pop(30); bq.pop(30); bq.pop(30); // shipname
		const unsigned type = bq.pop(8);
		const unsigned to_bow = bq.pop(9);
		const unsigned to_stern = bq.pop(9);
		const unsigned to_port = bq.pop(6);
		const unsigned to_starboard = bq.pop(6);
		bq.pop(4); // epfd
		bq.pop(4); // month
		bq.pop(5); // day
		bq.pop(5); // hour
		bq.pop(6); // minute
		const unsigned draught = bq.pop(8);

		print_static(id, mmsi, type, to_bow, to_stern, to_port, to_starboard, draught);
	}
};

class Message_18_19 : public Message
{
private:
	virtual void decode(bitqueue &bq)
	{
		const unsigned id = bq.pop(6);
		bq.pop(2); // repeat
		const unsigned mmsi = bq.pop(30);
		bq.pop(8); // reserved
		const unsigned speed = bq.pop(10);
		const unsigned accuracy = bq.pop(1);
		const int lon = bq.pop_signed(28);
		const int lat = bq.pop_signed(27);
		const unsigned course = bq.pop(12);
		const unsigned heading = bq.pop(9);

		const unsigned status = 16; // not defined in message

		print(id, mmsi, lat / 600000.0, lon / 600000.0, accuracy, status, speed / 10.0, course / 10.0, heading);
	}
};

class Message_24 : public Message
{
private:
	virtual void decode(bitqueue &bq)
	{
		const unsigned id = bq.pop(6);
		bq.pop(2); // repeat
		const unsigned mmsi = bq.pop(30);
		const unsigned partno = bq.pop(2);

		switch (partno)
		{
			case 1: // Part B
			{
				const unsigned type = bq.pop(8);
				bq.pop(18); // vendorid
				bq.pop(4); // model
				bq.pop(20); // serial
				bq.pop(20); bq.pop(22); // callsign
				const unsigned to_bow = bq.pop(9);
				const unsigned to_stern = bq.pop(9);
				const unsigned to_port = bq.pop(6);
				const unsigned to_starboard = bq.pop(6);
				bq.pop(6); // spare

				print_static(id, mmsi, type, to_bow, to_stern, to_port, to_starboard, 0);
				break;
			}

			default:
			{
				print_static(0, 0, 0, 0, 0, 0, 0, 0);
				break;
			}
		}

	}
};

class Message_27 : public Message
{
private:
	virtual void decode(bitqueue &bq)
	{
		const unsigned id = bq.pop(6);
		bq.pop(2); // repeat
		const unsigned mmsi = bq.pop(30);
		const unsigned accuracy = bq.pop(1);
		bq.pop(1); // raim
		const unsigned status = bq.pop(4);
		const int lon = bq.pop_signed(18);
		const int lat = bq.pop_signed(17);
		const unsigned speed = bq.pop(6);
		const unsigned course = bq.pop(9);
		const unsigned heading = bq.pop(9);

		print(id, mmsi, lat / 600.0, lon / 600.0, accuracy, status, speed, course, heading);
	}
};

int main(int argc, char **argv)
{
	if (argc < 2)
		return -1;

	ifstream f(argv[1]);

	vector<Message *> messages(28, nullptr);
	messages[0] = new Message;
	messages[1] = new Message_1_2_3;
	messages[2] = new Message_1_2_3;
	messages[3] = new Message_1_2_3;
	messages[5] = new Message_5;
	messages[18] = new Message_18_19;
	messages[19] = new Message_18_19;
	messages[24] = new Message_24;
	messages[27] = new Message_27;

	string s;
	bitqueue bq;

	while (!f.eof())
	{
		getline(f, s);

		if (s.size() > 0 && s[s.size() - 1] == '"')
			s.pop_back();

		if (s.size() > 0 && s[0] == '"')
			s.erase(0, 1);

		if (s.size() > 0 && s[0] == '!')
			s.erase(0, 1);

		if (s.size() > 0)
		{
			unsigned type = 0;
			const bool ok = Message::unpack(s, bq, type);

			if (!ok || type >= messages.size() || messages[type] == nullptr)
				type = 0;

			messages[type]->decode(bq);
		}
	}
}
