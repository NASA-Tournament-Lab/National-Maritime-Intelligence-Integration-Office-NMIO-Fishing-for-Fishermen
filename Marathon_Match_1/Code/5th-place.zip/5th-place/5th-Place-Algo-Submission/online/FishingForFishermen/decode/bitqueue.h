#include <queue>
#include <assert.h>

namespace utility
{
	class bitqueue
	{
		typedef unsigned int size_t;
		static const size_t BPB = sizeof(size_t) * 8; // BITS_PER_BLOCK;
	public:
		bitqueue();

		void clear();
		void push(size_t count, size_t value);
		size_t size() const;
		bool empty() const;

		size_t pop(size_t count);
		size_t pop_signed(size_t count);
		
	private:
		std::queue<unsigned int> queue_;
		size_t front_part_, front_bits_;
		size_t back_part_, back_bits_;

		static inline size_t mask(size_t size)
		{
			static const size_t masks[] =
			{
				0x0,
				0x1, 0x3, 0x7, 0xf,
				0x1f, 0x3f, 0x7f, 0xff,
				0x1ff, 0x3ff, 0x7ff, 0xfff,
				0x1fff, 0x3fff, 0x7fff, 0xffff,
				0x1ffff, 0x3ffff, 0x7ffff, 0xfffff,
				0x1fffff, 0x3fffff, 0x7fffff, 0xffffff,
				0x1ffffff, 0x3ffffff, 0x7ffffff, 0xfffffff,
				0x1fffffff, 0x3fffffff, 0x7fffffff, 0xffffffff,
			};

			assert(size < sizeof(masks) / sizeof(masks[0]));

			return masks[size];
		}

		static size_t take(size_t &count, size_t &value, size_t pinch)
		{
			assert(pinch <= count);

			const size_t result = (value >> (count - pinch)) & mask(pinch);
			value &= mask(count - pinch);
			count -= pinch;

			return result;
		}

		static inline size_t push(size_t where, size_t count, size_t value)
		{
			assert((value & mask(count)) == value);

			return (where << count) | value;
		}

		inline void deliver()
		{
			queue_.push(back_part_);
			back_part_ = back_bits_ = 0;

			assert(back_part_ == 0);
			assert(back_bits_ == 0);
			assert(queue_.size() > 0);
		}
	};
}

namespace utility
{
	bitqueue::bitqueue() :
		queue_(),
		front_part_(0),
		front_bits_(0),
		back_part_(0),
		back_bits_(0)
	{
	}

	void bitqueue::clear()
	{
		queue_ = decltype(queue_)();
		front_part_ = front_bits_ = 0;
		back_part_ = back_bits_ = 0;
	}

	void bitqueue::push(size_t count, size_t value)
	{
		assert(count <= BPB); // for now

		if (back_bits_ + count > BPB)
		{
			const size_t chunk = BPB - back_bits_;
			back_part_ = push(back_part_, chunk, take(count, value, chunk));
			deliver();

			assert(count < BPB);
		}

		assert(back_bits_ + count <= BPB);

		back_part_ = push(back_part_, count, value);
		back_bits_ += count;

		assert(back_bits_ <= BPB);

		if (back_bits_ == BPB)
			deliver();
	}

	bitqueue::size_t bitqueue::size() const
	{
		return front_bits_ + queue_.size() * BPB + back_bits_;
	}

	bool bitqueue::empty() const
	{
		return size() == 0;
	}

	bitqueue::size_t bitqueue::pop(size_t count)
	{
		assert(count <= BPB); // for now

		size_t result = 0;

		if (front_bits_ < count)
		{
			assert(queue_.size() > 0);

			result = front_part_;
			count -= front_bits_;
			front_part_ = queue_.front(); queue_.pop();
			front_bits_ = BPB;
		}

		assert(count <= front_bits_);

		result = (result << count) | take(front_bits_, front_part_, count);

		return result;
	}

	bitqueue::size_t bitqueue::pop_signed(size_t count)
	{
		size_t result = pop(count);

		if (((result >> (count - 1)) & 1) > 0)
			result = result | ~mask(count);

		return result;
	}
}
