public class Report {
    final int track;
    final String type;
    long time;
    double latitude, longitude, sog, oceanicDepth, chlorophyll, salinity, elevation, temperature, thermoclineDepth, eastwardVelocity, northVelocity;
    Report first, last;

    public Report(int track, String type, long time, double latitude, double longitude, double sog, double oceanicDepth, double chlorophyll, double salinity, double elevation, double temperature, double thermoclineDepth, double eastwardVelocity, double northVelocity) {
        this.type = type;
        this.track = track;
        this.time = time;
        this.latitude = latitude;
        this.longitude = longitude;
        this.sog = sog;
        this.oceanicDepth = oceanicDepth;
        this.chlorophyll = chlorophyll;
        this.salinity = salinity;
        this.elevation = elevation;
        this.temperature = temperature;
        this.thermoclineDepth = thermoclineDepth;
        this.eastwardVelocity = eastwardVelocity;
        this.northVelocity = northVelocity;
    }
}