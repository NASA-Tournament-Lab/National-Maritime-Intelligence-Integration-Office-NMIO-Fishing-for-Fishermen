import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;

public class RandomForestPredictor {
    private final int[] roots;
    private final float[] errors;
    private final int[] nodeLeft;
    private final short[] splitFeature;
    private final float[] value;
    private int trees, free;

    public RandomForestPredictor(int trees, int nodes, boolean max) {
        if (max) {
            roots = new int[trees];
            errors = new float[trees];
            int totalNodes = trees * nodes;
            nodeLeft = new int[totalNodes];
            splitFeature = new short[totalNodes];
            value = new float[totalNodes];
        } else {
            this.trees = trees;
            this.free = nodes;
            roots = new int[trees];
            errors = new float[trees];
            nodeLeft = new int[nodes];
            splitFeature = new short[nodes];
            value = new float[nodes];
        }
    }

    public synchronized void add(ClassificationNode root, float error) {
        errors[trees] = error;
        int rt = roots[trees++] = free;
        free++;
        expand(root, rt);
    }

    public int size() {
        return trees;
    }

    private void expand(ClassificationNode node, int pos) {
        if (node.left == null) {
            nodeLeft[pos] = -1;
            splitFeature[pos] = -1;
            value[pos] = node.getValue();
        } else {
            int l = nodeLeft[pos] = free;
            free += 2;
            splitFeature[pos] = (short) node.splitFeature;
            value[pos] = node.splitVal;
            expand(node.left, l);
            expand(node.right, l + 1);
        }
    }

    public double predict(float[] features) {
        double ret = 0;
        for (int i = 0; i < roots.length; i++) {
            ret += classify(roots[i], features);
        }
        return ret / roots.length;
    }

    private double classify(int pos, float[] features) {
        while (true) {
            int sf = splitFeature[pos];
            if (sf < 0) return value[pos];
            if (features[sf] < value[pos]) pos = nodeLeft[pos];
            else pos = nodeLeft[pos] + 1;
        }
    }

    public void save(File file) throws Exception {
        DataOutputStream out = new DataOutputStream(new BufferedOutputStream(new FileOutputStream(file), 1 << 20));
        out.writeInt(trees);
        for (int i = 0; i < trees; i++) {
            out.writeInt(roots[i]);
        }
        for (int i = 0; i < trees; i++) {
            out.writeFloat(errors[i]);
        }
        out.writeInt(free);
        for (int i = 0; i < free; i++) {
            out.writeShort(splitFeature[i]);
            out.writeInt(nodeLeft[i]);
            out.writeFloat(value[i]);
        }
        out.close();
    }

    public static RandomForestPredictor load(File file, int maxTrees) throws Exception {
        int[] cnt = new int[65536];
        DataInputStream in = new DataInputStream(new BufferedInputStream(new FileInputStream(file), 1 << 20));
        int trees = in.readInt();
        int[] t = new int[trees];
        for (int i = 0; i < trees; i++) {
            t[i] = in.readInt();
        }
        float[] e = new float[trees];
        for (int i = 0; i < trees; i++) {
            e[i] = in.readFloat();
        }
        int nodes = in.readInt();
        if (maxTrees > 0 && trees > maxTrees) {
            trees = maxTrees;
            nodes = t[trees] + 1;
        }
        RandomForestPredictor predictor = new RandomForestPredictor(trees, nodes, false);
        System.arraycopy(t, 0, predictor.roots, 0, trees);
        System.arraycopy(e, 0, predictor.errors, 0, trees);
        byte[] bytes = new byte[10];
        for (int i = 0; i < nodes; i++) {
            in.read(bytes);
            short splitFeature = predictor.splitFeature[i] = (short) (((bytes[0] & 0xFF) << 8) + ((bytes[1] & 0xFF) << 0));
            if (splitFeature >= 0) cnt[splitFeature]++;
            predictor.nodeLeft[i] = (((bytes[2] & 0xFF) << 24) + ((bytes[3] & 0xFF) << 16) + ((bytes[4] & 0xFF) << 8) + ((bytes[5] & 0xFF) << 0));
            predictor.value[i] = Float.intBitsToFloat((((bytes[6] & 0xFF) << 24) + ((bytes[7] & 0xFF) << 16) + ((bytes[8] & 0xFF) << 8) + ((bytes[9] & 0xFF) << 0)));
        }
        in.close();
        /*
        System.err.println("\t\t    Trees: " + trees);
        System.err.println("\t\tAvg.Nodes: " + nodes / trees);
        for (int i = 0; i < cnt.length; i++) {
            if (cnt[i] > 0) System.err.println("\t\t\t" + i + "\t" + cnt[i]);
        }
        */
        return predictor;
    }
}