import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.SplittableRandom;

public class Track {
    private static final Map<String, List<double[]>> trackMemo = new HashMap<String, List<double[]>>();
    final ArrayList<Report> reports = new ArrayList<Report>();
    final int number;
    final String type;

    public Track(int number, File trackFile) throws Exception {
        this(number, trackFile, null);
    }

    public Track(int number, File trackFile, String type) throws Exception {
        this(number, trackFile, type, null, 0, 0);
    }

    public Track(int number, File trackFile, String type, SplittableRandom rnd, int sampleRate1, int sampleRate2) throws Exception {
        this.number = number;
        this.type = type;

        List<double[]> values = null;
        boolean add = false;
        synchronized (trackMemo) {
            values = trackMemo.get(trackFile.getName());
            if (values == null) {
                trackMemo.put(trackFile.getName(), values = new ArrayList<double[]>());
                add = true;
            }
        }
        if (add) {
            BufferedReader in = new BufferedReader(new FileReader(trackFile), 1 << 20);
            String line = in.readLine();
            double longMin1 = 180;
            double longMax1 = -180;
            double longMin2 = 180;
            double longMax2 = -180;
            NEXT: while ((line = in.readLine()) != null) {
                String[] s = line.split(",");
                if (s.length < 13) continue;
                double[] v = new double[13];
                for (int i = 1; i < 13; i++) {
                    v[i] = Double.parseDouble(s[i]);
                    if (i == 2) {
                        double latitude = v[i];
                        if (latitude > 90 || latitude < -90) continue NEXT;
                    }
                    if (i == 3) {
                        double longitude1 = v[i];
                        if (longitude1 > 180 || longitude1 < -180) continue NEXT;
                        if (longitude1 < longMin1) longMin1 = longitude1;
                        if (longitude1 > longMax1) longMax1 = longitude1;
                        double longitude2 = longitude1;
                        if (longitude2 < 0) longitude2 += 360;
                        if (longitude2 < longMin2) longMin2 = longitude2;
                        if (longitude2 > longMax2) longMax2 = longitude2;
                    }
                }
                values.add(v);
            }
            in.close();
            if (longMax1 - longMin1 > longMax2 - longMin2) {
                for (double[] v : values) {
                    if (v[3] < 0) v[3] += 360;
                }
            }
        }
        reports.ensureCapacity(values.size());
        for (double[] v : values) {
            double latitude = v[2];
            double longitude = v[3];
            Report r = new Report(number, type, (long) v[1], latitude, longitude, v[4], v[5], v[6], v[7], v[8], v[9], v[10], v[11], v[12]);
            if (sampleRate1 < 0 && !reports.isEmpty() && rnd.nextInt(-sampleRate1) < sampleRate2) continue;
            if (sampleRate1 > 0 && !reports.isEmpty() && rnd.nextInt(sampleRate1) < Math.abs(sampleRate2)) {
                Report p = reports.get(reports.size() - 1);
                double a = rnd.nextDouble();
                double b = 1 - a;
                Report m = new Report(number, type, (long) (r.time * a + b * p.time), r.latitude * a + b * p.latitude, r.longitude * a + b * p.longitude, mix(r.sog, p.sog, a, b), mix(r.oceanicDepth, p.oceanicDepth, a, b), mix(r.chlorophyll, p.chlorophyll, a, b), mix(r.salinity, p.salinity, a, b),
                        mix(r.elevation, p.elevation, a, b), mix(r.temperature, p.temperature, a, b), mix(r.thermoclineDepth, p.thermoclineDepth, a, b), mix(r.eastwardVelocity, p.eastwardVelocity, a, b), mix(r.northVelocity, p.northVelocity, a, b));
                reports.add(m);
                if (sampleRate2 >= 0) reports.add(r);
            } else {
                reports.add(r);
            }
        }
        if (sampleRate1 == 0) {
            if (sampleRate2 > 0) {
                if (reports.size() > 2) {
                    int p = rnd.nextInt(reports.size() / 2);
                    reports.subList(0, p).clear();
                }
                if (reports.size() > 2) {
                    int p = rnd.nextInt(reports.size() / 2) + reports.size() / 2;
                    reports.subList(p, reports.size()).clear();
                }
            } else if (sampleRate2 < 0) {
                if (reports.size() > 2) {
                    int p1 = rnd.nextInt(reports.size() / 2);
                    int p2 = rnd.nextInt(reports.size() / 2) + reports.size() / 2;
                    if (p2 > p1) reports.subList(p1, p2).clear();
                }
            }
        }
        long start = reports.get(0).time;
        if (start > 0) {
            for (Report r : reports) {
                r.time -= start;
            }
        }
        Report first = reports.get(0);
        Report last = reports.get(reports.size() - 1);
        for (Report r : reports) {
            r.first = first;
            r.last = last;
        }
    }

    private static double mix(double x, double y, double a, double b) {
        if (x == -99999) return y;
        if (y == -99999) return x;
        return x * a + y * b;
    }
}