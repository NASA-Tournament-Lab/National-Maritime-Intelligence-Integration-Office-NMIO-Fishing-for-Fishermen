import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class TrackFeatureExtractor {
    public static int numBins = 16;
    private int numStats = 3 + numBins;
    private int numSeries = 11;
    public int numFeatures = numSeries * (numStats + 1) + 7;
    private final Track track;

    public TrackFeatureExtractor(Track track) {
        this.track = track;
    }

    public float[] getFeatures() {
        float[] ret = new float[numFeatures];

        Report first = track.reports.get(0);
        Report last = track.reports.get(track.reports.size() - 1);
        int k = 0;
        List<Double> v = new ArrayList<Double>();
        List<Double> a = new ArrayList<Double>();
        for (int i = 0; i < numSeries; i++) {
            v.clear();
            a.clear();
            Report prev = first;
            double div = 0;
            for (Report r : track.reports) {
                long dt = r.time - prev.time;
                double x = 0;
                if (i == 0) x = r.chlorophyll;
                else if (i == 1) x = r.eastwardVelocity;
                else if (i == 2) x = r.northVelocity;
                else if (i == 3) x = r.elevation;
                else if (i == 4) x = r.latitude;
                else if (i == 5) x = r.longitude;
                else if (i == 6) x = r.oceanicDepth;
                else if (i == 7) x = r.salinity;
                else if (i == 8) x = r.sog;
                else if (i == 9) x = r.temperature;
                else if (i == 10) x = dt == 0 ? 0 : Util.haversine(r.latitude, r.longitude, prev.latitude, prev.longitude) / dt;
                a.add(x * dt);
                div += dt;
                v.add(x);
                prev = r;
            }
            if (i == 10) v.remove(0);
            System.arraycopy(stats(v, i == 5), 0, ret, k, numStats);
            k += numStats;
            ret[k++] = avg(a, div, i == 5);
        }

        ret[k++] = (float) (last.time - first.time);
        ret[k++] = track.reports.size();
        ret[k++] = (float) first.latitude;
        ret[k++] = (float) first.longitude;
        return ret;
    }

    private final float[] stats(List<Double> v, boolean angle) {
        Collections.sort(v);
        double sum = 0;
        int cnt = 0;
        double min = Double.MAX_VALUE;
        double max = Double.MIN_VALUE;
        for (double x : v) {
            if (x == -99999) continue;
            sum += x;
            cnt++;
            if (x < min) min = x;
            if (x > max) max = x;
        }
        float[] ret = new float[numStats];
        if (cnt > 0) {
            ret[0] = (float) (sum / cnt);
            if (angle && ret[0] > 180) ret[0] -= 360;
            ret[1] = (float) (max - min);
            cnt = v.size();
            for (int i = 0; i <= numBins; i++) {
                int pos = (int) Math.round(i * (double) cnt / numBins);
                if (pos >= cnt) pos = cnt - 1;
                ret[i + 2] = v.get(pos).floatValue();
                if (angle && ret[i + 2] > 180) ret[i + 2] -= 360;
            }
        }
        return ret;
    }

    private static final float avg(List<Double> v, double div, boolean angle) {
        double sum = 0;
        for (double x : v) {
            sum += x;
        }
        if (div > 0) sum /= div;
        if (angle && sum > 180) sum -= 360;
        return (float) sum;
    }
}