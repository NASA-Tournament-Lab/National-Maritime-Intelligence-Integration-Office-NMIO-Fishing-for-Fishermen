public class Prediction {
    final int trackNumber;
    final String type;
    double probability;

    public Prediction(int trackNumber, String type, double probability) {
        this.trackNumber = trackNumber;
        this.type = type;
        this.probability = probability;
    }
}
