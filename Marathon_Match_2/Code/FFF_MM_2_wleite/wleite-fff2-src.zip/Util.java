import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.SplittableRandom;

public class Util {

    public static Map<Integer, String> readTrackTypeByNumber(File dataFile) {
        Map<Integer, String> trackNumbers = new HashMap<Integer, String>();
        String line = null;
        int numRows = 0;
        try {
            System.err.println("Reading Tracks");
            long t = System.currentTimeMillis();
            BufferedReader in = new BufferedReader(new FileReader(dataFile));
            while ((line = in.readLine()) != null) {
                if (line.trim().isEmpty()) continue;
                String[] s = line.split(",");
                trackNumbers.put(Integer.parseInt(s[0]), s.length == 1 ? null : s[1].trim().intern());
                numRows++;
            }
            in.close();
            System.err.println("\t     Rows Read: " + numRows);
            System.err.println("\t  Elapsed Time: " + (System.currentTimeMillis() - t) + " ms");
            System.err.println();
        } catch (Exception e) {
            e.printStackTrace();
            System.exit(-1);
        }
        return trackNumbers;
    }

    public static void splitTracks(Map<Integer, String> tracksNumbers, int[] a, int idx) {
        try {
            System.err.println("Spliting Tracks");
            long t = System.currentTimeMillis();
            List<Integer> l = new ArrayList<Integer>(tracksNumbers.keySet());
            SplittableRandom rnd = new SplittableRandom(2014_08_19_2012_06_22L);
            for (int i = 0; i < l.size() * l.size(); i++) {
                int p1 = rnd.nextInt(l.size());
                int p2 = rnd.nextInt(l.size());
                Collections.swap(l, p1, p2);
            }
            int p1 = 0;
            for (int i = 0; i < idx; i++) {
                p1 += a[i];
            }
            int p2 = p1 + a[idx];
            p1 = p1 * l.size() / 100;
            p2 = p2 * l.size() / 100;
            if (p2 > l.size()) p2 = l.size();
            tracksNumbers.keySet().retainAll(l.subList(p1, p2));
            System.err.println("\t        Tracks: " + tracksNumbers.size());
            System.err.println("\t  Elapsed Time: " + (System.currentTimeMillis() - t) + " ms");
            System.err.println();
        } catch (Exception e) {
            e.printStackTrace();
            System.exit(-2);
        }
    }

    public static final double haversine(double lat1, double lon1, double lat2, double lon2) {
        double dLat = Math.toRadians(lat2 - lat1);
        double dLon = Math.toRadians(lon2 - lon1);
        lat1 = Math.toRadians(lat1);
        lat2 = Math.toRadians(lat2);
        return 12745.6 * Math.asin(Math.sqrt(Math.pow(Math.sin(dLat / 2), 2) + Math.pow(Math.sin(dLon / 2), 2) * Math.cos(lat1) * Math.cos(lat2)));
    }
}