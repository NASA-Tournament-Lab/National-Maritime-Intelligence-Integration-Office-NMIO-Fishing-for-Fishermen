public class ReportFeatureExtractor {
    public static final int numFeatures = 12;
    private final Report report;

    public ReportFeatureExtractor(Report report) {
        this.report = report;
    }

    public float[] getFeatures() {
        float[] ret = new float[numFeatures];
        int k = 0;
        ret[k++] = (float) report.chlorophyll;
        ret[k++] = (float) report.eastwardVelocity;
        ret[k++] = (float) report.northVelocity;
        ret[k++] = (float) report.elevation;
        ret[k++] = (float) report.latitude;
        ret[k++] = (float) (report.longitude > 180 ? report.longitude - 360 : report.longitude);
        ret[k++] = (float) report.oceanicDepth;
        ret[k++] = (float) report.salinity;
        ret[k++] = (float) report.sog;
        ret[k++] = (float) report.temperature;
        ret[k++] = (float) report.thermoclineDepth;
        ret[k++] = (float) Util.haversine(report.first.latitude, report.first.longitude, report.latitude, report.longitude);
        return ret;
    }
}