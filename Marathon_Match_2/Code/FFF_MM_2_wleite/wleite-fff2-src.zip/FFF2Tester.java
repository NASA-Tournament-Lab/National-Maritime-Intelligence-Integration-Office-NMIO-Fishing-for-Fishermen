import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

public class FFF2Tester {
    private Map<String, RandomForestPredictor> reportsPredictorByType, tracksPredictorByType;
    private Map<Integer, String> trackTypeByNumber;
    private final List<Prediction> predictions = new ArrayList<Prediction>();

    public static void run() {
        File dataFile = new File(FFF2Main.isLocalTest ? FFF2Main.trainingFile : FFF2Main.testingFile);
        File tracksFolder = new File(FFF2Main.tracksFolder);
        File modelFolder = new File(FFF2Main.modelFolder);
        File answerFile = new File(FFF2Main.answerFile);
        new FFF2Tester().runTest(dataFile, tracksFolder, modelFolder, answerFile);
    }

    public void runTest(File dataFile, File tracksFolder, File modelFolder, File answerFile) {
        loadPredictors(modelFolder);
        trackTypeByNumber = Util.readTrackTypeByNumber(dataFile);
        if (FFF2Main.isLocalTest) Util.splitTracks(trackTypeByNumber, new int[] {80,20}, 1);
        processTracks(tracksFolder);
        writeAnswer(answerFile);
        if (FFF2Main.isLocalTest) localScore();
    }

    private void processTracks(final File tracksFolder) {
        try {
            System.err.println("Processing Tracks");
            long t = System.currentTimeMillis();
            final List<Integer> numbers = new ArrayList<Integer>(trackTypeByNumber.keySet());
            Collections.sort(numbers, new Comparator<Integer>() {
                public int compare(Integer a, Integer b) {
                    return a.compareTo(b);
                }
            });
            final Thread[] threads = new Thread[FFF2Main.numThreads];
            for (int i = 0; i < threads.length; i++) {
                final int start = i;
                threads[i] = new Thread() {
                    public void run() {
                        for (int j = start; j < numbers.size(); j += threads.length) {
                            int number = numbers.get(j);
                            try {
                                File trackFile = new File(tracksFolder, number + ".csv");
                                processTrack(new Track(number, trackFile));
                            } catch (Exception e) {
                                e.printStackTrace();
                            }
                        }
                    }
                };
                threads[i].start();
            }
            for (int i = 0; i < threads.length; i++) {
                threads[i].join();
                threads[i] = null;
            }
            Collections.sort(predictions, new Comparator<Prediction>() {
                public int compare(Prediction a, Prediction b) {
                    int cmp = 0;
                    if ((cmp = a.type.compareTo(b.type)) != 0) return cmp;
                    if ((cmp = Double.compare(b.probability, a.probability)) != 0) return cmp;
                    if ((cmp = Integer.compare(a.trackNumber, b.trackNumber)) != 0) return cmp;
                    return 0;
                }
            });
            double v = 1;
            Prediction prev = null;
            for (Prediction p : predictions) {
                if (prev != null && !prev.type.equals(p.type)) {
                    v = 1;
                }
                p.probability = v;
                v *= 0.999;
                prev = p;
            }
            System.err.println("\t  Elapsed Time: " + (System.currentTimeMillis() - t) + " ms");
            System.err.println();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void processTrack(Track track) throws Exception {
        TrackFeatureExtractor ext = new TrackFeatureExtractor(track);
        float[] features = ext.getFeatures();
        Map<String, Double> values1 = new HashMap<String, Double>();
        Map<String, Double> values2 = new HashMap<String, Double>();
        for (String type : tracksPredictorByType.keySet()) {
            RandomForestPredictor predictor = tracksPredictorByType.get(type);
            double v = predictor.predict(features);
            values1.put(type, v);
        }

        for (String type : reportsPredictorByType.keySet()) {
            RandomForestPredictor predictor = reportsPredictorByType.get(type);
            double v = 0;
            int cnt = 0;
            for (Report r : track.reports) {
                v += predictor.predict(new ReportFeatureExtractor(r).getFeatures());
                cnt++;
            }
            if (cnt > 0) v /= cnt;
            values2.put(type, v);
        }

        Map<String, Double> values = new HashMap<String, Double>();
        for (String type : values1.keySet()) {
            double v1 = values1.get(type);
            double v2 = values2.get(type);
            values.put(type, v1 + v2 / 6);
        }
        double tot = 0;
        double first = 0;
        double second = 0;
        String best = "";
        for (String type : values.keySet()) {
            double v = values.get(type);
            values.put(type, v);
            tot += v;
            if (v > first) {
                second = first;
                first = v;
                best = type;
            } else if (v > second) {
                second = v;
            }
        }
        double bonus = first - second;
        tot += bonus;
        synchronized (predictions) {
            for (String type : values.keySet()) {
                double v = values.get(type);
                if (type.equals(best)) v += bonus;
                if (tot > 0) v /= tot;
                predictions.add(new Prediction(track.number, type, v));
            }
        }
    }

    private void writeAnswer(File answerFile) {
        try {
            DecimalFormat df = new DecimalFormat("0.0000000000", DecimalFormatSymbols.getInstance(Locale.US));
            BufferedWriter out = new BufferedWriter(new FileWriter(answerFile));
            for (Prediction p : predictions) {
                if (p.type.equalsIgnoreCase("other")) continue;
                StringBuilder sb = new StringBuilder();
                sb.append(p.trackNumber);
                sb.append(',');
                sb.append(p.type);
                sb.append(',');
                sb.append(df.format(p.probability));
                out.write(sb.toString());
                out.newLine();
            }
            out.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void loadPredictors(File modelFolder) {
        tracksPredictorByType = new HashMap<String, RandomForestPredictor>();
        reportsPredictorByType = new HashMap<String, RandomForestPredictor>();
        try {
            long t = System.currentTimeMillis();
            System.err.println("Loading Predictors");
            String suffix = ".dat";
            File[] files = modelFolder.listFiles();
            for (File file : files) {
                if (file.getName().toLowerCase().endsWith(suffix)) {
                    RandomForestPredictor predictor = RandomForestPredictor.load(file, -1);
                    String name = file.getName().substring(0, file.getName().length() - suffix.length());
                    int pos = name.indexOf('-') + 1;
                    if (name.startsWith("tracks-")) {
                        tracksPredictorByType.put(name.substring(pos), predictor);
                    } else if (name.startsWith("reports-")) {
                        reportsPredictorByType.put(name.substring(pos), predictor);
                    }
                }
            }
            System.err.println("\t  Elapsed Time: " + (System.currentTimeMillis() - t) + " ms\n");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void localScore() {
        String[] types = {"trawler","seiner","longliner","support"};
        double sum = 0;
        double[] weights = new double[] {0.4,0.3,0.2,0.1};
        for (int idx = 0; idx < types.length; idx++) {
            String type = types[idx];
            double weight = weights[idx];

            List<double[]> l = new ArrayList<double[]>();
            int P = 0;
            int N = 0;
            int cnt = 0;
            Map<Integer, String> truth = new HashMap<Integer, String>();
            truth.putAll(trackTypeByNumber);
            for (Prediction p : predictions) {
                if (!p.type.equals(type)) continue;
                String thuthType = truth.remove(p.trackNumber);
                if (thuthType == null) return;
                boolean positive = thuthType.equals(type);
                if (positive) P++;
                else N++;
                double[] v = new double[] {Math.max(0, Math.min(1, p.probability)),positive ? 1 : 0,cnt++};
                l.add(v);
            }
            double tpri = 0;
            double fpri = 0;
            double auc = 0;
            double prev = 0;
            for (int i = 0; i < l.size(); i++) {
                double[] v = l.get(i);
                tpri += v[1] / P;
                fpri += (1 - v[1]) / N;
                auc += tpri * (fpri - prev);
                prev = fpri;
            }
            double score = 1_000_000 * (2 * auc - 1);
            String s = "Score[" + type + "] = ";
            while (s.length() < 20) {
                s = ' ' + s;
            }
            System.err.println("\t" + s + (int) score);
            sum += weight * score;
        }
        System.err.println("\t      Final Score = " + (int) sum);
    }
}
