import java.io.File;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.SortedMap;
import java.util.SplittableRandom;
import java.util.TreeMap;

public class FFF2Trainer {
    private float[][] features;
    private boolean[] classif;
    private final SortedMap<String, Integer> trackTypes = new TreeMap<String, Integer>();
    private Map<Integer, String> trackTypeByNumber;
    private List<Report> reports = new ArrayList<Report>();
    private String[] tracksType;
    static int augmentation = 12;

    public static void run() {
        File dataFile = new File(FFF2Main.trainingFile);
        File tracksFolder = new File(FFF2Main.tracksFolder);
        File modelFolder = new File(FFF2Main.modelFolder);
        if (!modelFolder.exists()) modelFolder.mkdirs();
        new FFF2Trainer().train(dataFile, tracksFolder, modelFolder);
    }

    public void train(File dataFile, File tracksFolder, File modelFolder) {
        trackTypeByNumber = Util.readTrackTypeByNumber(dataFile);
        if (FFF2Main.isLocalTest) Util.splitTracks(trackTypeByNumber, new int[] {80,20}, 0);
        processTracks(tracksFolder);
        buildTracksRandomForests(modelFolder);
        processReports();
        buildReportsRandomForests(modelFolder);
    }

    private void processTracks(final File tracksFolder) {
        try {
            System.err.println("Processing Tracks");
            long t = System.currentTimeMillis();
            final List<Integer> numbers = new ArrayList<Integer>(trackTypeByNumber.keySet());
            Collections.sort(numbers, new Comparator<Integer>() {
                public int compare(Integer a, Integer b) {
                    return a.compareTo(b);
                }
            });
            final int[] sampleRate1 = new int[] {0,1,0,0,0,0,2,0,0,-3,-3,3,-2};
            final int[] sampleRate2 = new int[] {0,-1,-1,1,-2,2,1,3,-3,1,2,2,1};
            TrackFeatureExtractor aux = new TrackFeatureExtractor(null);
            features = new float[aux.numFeatures][numbers.size() * (augmentation + 1)];
            classif = new boolean[numbers.size() * (augmentation + 1)];
            tracksType = new String[numbers.size() * (augmentation + 1)];
            final Thread[] threads = new Thread[FFF2Main.numThreads];
            for (int i = 0; i < threads.length; i++) {
                final int start = i;
                threads[i] = new Thread() {
                    public void run() {
                        for (int j = start; j < numbers.size(); j += threads.length) {
                            SplittableRandom rnd = new SplittableRandom(9999999999L * j + 1972);
                            int number = numbers.get(j);
                            String type = trackTypeByNumber.get(number);
                            synchronized (trackTypes) {
                                Integer cnt = trackTypes.get(type);
                                if (cnt == null) cnt = 0;
                                trackTypes.put(type, cnt + 1);
                            }
                            try {
                                Track track = new Track(number, new File(tracksFolder, number + ".csv"), type);
                                processTrack(track, j);
                                synchronized (reports) {
                                    reports.addAll(track.reports);
                                }
                                for (int k = 1; k <= augmentation; k++) {
                                    track = new Track(number + k * 10000000, new File(tracksFolder, number + ".csv"), type, rnd, sampleRate1[k], sampleRate2[k]);
                                    processTrack(track, j + k * numbers.size());
                                }
                            } catch (Exception e) {
                                e.printStackTrace();
                            }
                        }
                    }
                };
                threads[i].start();
            }
            for (int i = 0; i < threads.length; i++) {
                threads[i].join();
                threads[i] = null;
            }
            for (String type : trackTypes.keySet()) {
                String s = type;
                while (s.length() < 14) {
                    s = ' ' + s;
                }
                System.err.println("\t" + s + ": " + trackTypes.get(type));
            }
            System.err.println("\t       Reports: " + reports.size());
            System.err.println("\t  Elapsed Time: " + (System.currentTimeMillis() - t) + " ms");
            System.err.println();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void processReports() {
        try {
            System.err.println("Processing Reports");
            long t = System.currentTimeMillis();
            Collections.sort(reports, new Comparator<Report>() {
                public int compare(Report a, Report b) {
                    int cmp = 0;
                    if ((cmp = Integer.compare(a.track, b.track)) != 0) return cmp;
                    if ((cmp = Long.compare(a.time, b.time)) != 0) return cmp;
                    return 0;
                }
            });
            features = new float[ReportFeatureExtractor.numFeatures][reports.size()];
            classif = new boolean[reports.size()];
            tracksType = new String[reports.size()];
            final Thread[] threads = new Thread[FFF2Main.numThreads];
            for (int i = 0; i < threads.length; i++) {
                final int start = i;
                threads[i] = new Thread() {
                    public void run() {
                        for (int j = start; j < reports.size(); j += threads.length) {
                            Report r = reports.get(j);
                            tracksType[j] = r.type;
                            ReportFeatureExtractor ext = new ReportFeatureExtractor(r);
                            float[] arrFeatures = ext.getFeatures();
                            for (int i = 0; i < arrFeatures.length; i++) {
                                features[i][j] = arrFeatures[i];
                            }
                        }
                    }
                };
                threads[i].start();
            }
            for (int i = 0; i < threads.length; i++) {
                threads[i].join();
                threads[i] = null;
            }
            System.err.println("\t  Elapsed Time: " + (System.currentTimeMillis() - t) + " ms");
            System.err.println();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void processTrack(Track track, int idx) {
        try {
            tracksType[idx] = track.type;
            TrackFeatureExtractor ext = new TrackFeatureExtractor(track);
            float[] arrFeatures = ext.getFeatures();
            for (int i = 0; i < arrFeatures.length; i++) {
                features[i][idx] = arrFeatures[i];
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void buildTracksRandomForests(File rfFolder) {
        try {
            for (String type : trackTypes.keySet()) {
                long t = System.currentTimeMillis();
                for (int i = 0; i < classif.length; i++) {
                    classif[i] = type.equalsIgnoreCase(tracksType[i]);
                }
                System.err.println("Building Tracks Random Forest - " + type.toUpperCase());
                File rfFile = new File(rfFolder, "tracks-" + type + ".dat");
                RandomForestBuilder.train(features, classif, classif.length, 512, rfFile, FFF2Main.numThreads, 3, features.length);
                System.err.println("\t   RF Building: " + rfFile.length() + " bytes");
                System.err.println("\t  Elapsed Time: " + (System.currentTimeMillis() - t) + " ms");
                System.err.println();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void buildReportsRandomForests(File rfFolder) {
        try {
            for (String type : trackTypes.keySet()) {
                long t = System.currentTimeMillis();
                for (int i = 0; i < classif.length; i++) {
                    classif[i] = type.equalsIgnoreCase(tracksType[i]);
                }
                System.err.println("Building Reports Random Forest - " + type.toUpperCase());
                File rfFile = new File(rfFolder, "reports-" + type + ".dat");
                RandomForestBuilder.train(features, classif, classif.length, 256, rfFile, FFF2Main.numThreads, 8, features.length / 2);
                System.err.println("\t   RF Building: " + rfFile.length() + " bytes");
                System.err.println("\t  Elapsed Time: " + (System.currentTimeMillis() - t) + " ms");
                System.err.println();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}