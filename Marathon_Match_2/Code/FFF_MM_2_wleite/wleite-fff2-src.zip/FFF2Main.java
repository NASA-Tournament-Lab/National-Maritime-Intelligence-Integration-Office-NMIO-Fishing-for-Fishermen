public class FFF2Main {
    public static String tracksFolder = "data/VesselTracks";
    public static String trainingFile = "data/training.txt";
    public static String testingFile = "data/testing.txt";
    public static String modelFolder = "model";
    public static String answerFile = "result/res.csv";
    public static boolean isLocalTest = !true;
    public static int numThreads = Runtime.getRuntime().availableProcessors();

    public static void main(String[] args) throws Exception {
        String mode = "?";

        //mode = "test";
        if (args.length >= 1) mode = args[0];
        if (args.length >= 2) tracksFolder = args[1]; 
        if (args.length >= 4) modelFolder = args[3]; 

        if (mode.equalsIgnoreCase("train")) {
            if (args.length >= 3) trainingFile = args[2]; 
            FFF2Trainer.run();
        } else if (mode.equalsIgnoreCase("test")) {
            if (args.length >= 3) testingFile = args[2];
            if (args.length >= 5) answerFile = args[4]; 
            FFF2Tester.run();
        } else {
            System.err.println("ERROR: Unknown mode (" + mode + ").");
        }
    }
}